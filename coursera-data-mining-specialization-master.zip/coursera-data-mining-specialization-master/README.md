# Data Mining Specialization
## Coursera / University of Illinois at Urbana-Champaign

Here are my projects from the following specialization: https://www.coursera.org/specializations/data-mining

**Author:** Michael Onishi<br/>
**Date:** October and November 2019
